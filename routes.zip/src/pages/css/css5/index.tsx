/*
 * @Author: SunLxy
 * @Date: 2023-07-24 07:33:19
 * @LastEditTime: 2023-07-24 07:33:20
 * @LastEditors: SunLxy
 * @Description: In User Settings Edit
 * @FilePath: /saqu/examples/routes/src/pages/css/css5/index.tsx
 */
const Index = () => {
  return <div>Index文件</div>;
};
export const element = <Index />;
